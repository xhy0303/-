it = iter(range(100))

66 in it # => True
print(next(it)) # => ??
print(33 in it) # => ??
print(next(it)) # => ??