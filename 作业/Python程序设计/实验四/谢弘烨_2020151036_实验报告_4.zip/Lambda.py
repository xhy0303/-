print((lambda val: val % 2)(5))
print((lambda x, y: x ^ y)(3, 8))
print((lambda s: s.strip().lower()[1:4])(' PyTHon'))