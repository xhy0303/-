
public class test {

}
/*
 * synchronized public void run()
	{
		ActionListener al=new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				if(e.getSource() instanceof JRadioButton)
				{
					JRadioButton src=(JRadioButton)e.getSource();
					time_s=0;
					Time_per.setText("����ʱ�䣺"+(time_s));
					count_que++;
					Count_que.setText("�Ѵ�"+count_que);
					if(src.getText()==src.getParent().getName())
					{
						score++;
						Score.setText("�ɼ���"+score);
					}
					if(src.getText()=="A"||src.getText()=="B"||src.getText()=="C"||src.getText()=="D")
					{
						count_sig++;
						Count_sig.setText("������ѡ����Ŀ��"+count_sig);
						if(src.getText()==src.getParent().getName())
						{
							count_t_sig++;
							Count_t_sig.setText("��ȷ��ѡ����Ŀ��"+count_t_sig);
						}
					}
					else
					{
						count_row++;
						Count_row.setText("�������ж�����Ŀ��"+count_row);
						if(src.getText()==src.getParent().getName())
						{
							count_t_row++;
							Count_t_row=new JLabel("��ȷ�ж�����Ŀ��"+count_t_row);
						}
					}
					validate();
					
					System.out.println(Thread.currentThread().getName()+" "+Thread.currentThread().equals(giveQuestion)+" "+giveQuestion.isAlive());
					notifyAll();
					try {
						Thread.currentThread().wait();
					} catch (InterruptedException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
					
				}
				else
				{
					
				}
			}
		};
				
		for(int n0=0;n0<15;n0++)
		{
			System.out.println(n0+" "+Thread.currentThread().getName()+" "+Thread.currentThread().equals(giveQuestion)+" "+giveQuestion.isAlive());
			JPanel panel=new JPanel();
			JLabel que;
			group=new ButtonGroup();
			if(n0<5)//��ѡ
			{
				Box b=Box.createVerticalBox();
				int sign0=(int)Math.random()*10;
				que=new JLabel(sigle[sign0].q);
				b.add(que);
				b.add(Box.createVerticalStrut(5));
				b.add(new  JLabel("����Ϊ1�ֵ�ѡ�⣬����20�����������\n"));
				b.add(Box.createVerticalStrut(5));
				panel.setBackground(Color.LIGHT_GRAY);
				Box b0=Box.createHorizontalBox();
				A=new JRadioButton("A");
				B=new JRadioButton("B");
				C=new JRadioButton("C");
				D=new JRadioButton("D");
				
				group.add(A);
				group.add(B);
				group.add(C);
				group.add(D);
				
				A.addActionListener(al);
				B.addActionListener(al);
				C.addActionListener(al);
				D.addActionListener(al);
				
				
				b0.add(A);
				b0.add(B);
				b0.add(C);
				b0.add(D);
				b0.setName(sigle[sign0].ans);
				b.add(b0);
				panel.add(b);
				
			}
			else if(n0<10)//��ѡ
			{
				Box b=Box.createVerticalBox();
				int sign0=(int)Math.random()*10;
				que=new JLabel(mutiple[sign0].q);
				b.add(que);
				b.add(Box.createVerticalStrut(5));
				b.add(new  JLabel("����Ϊ2�ֶ�ѡ�⣬����20�����������\n"));
				b.add(Box.createVerticalStrut(5));
				panel.setBackground(Color.LIGHT_GRAY);
				Box b0=Box.createHorizontalBox();
				A0=new JCheckBox("A");
				B0=new JCheckBox("B");
				C0=new JCheckBox("C");
				D0=new JCheckBox("D");
				
				
				
				A0.addActionListener(al);
				B0.addActionListener(al);
				C0.addActionListener(al);
				D0.addActionListener(al);
				
				
				b0.add(A0);
				b0.add(B0);
				b0.add(C0);
				b0.add(D0);
				b0.setName(mutiple[sign0].ans);
				b.add(b0);
				panel.add(b);
				
			}
			else
			{
				Box b=Box.createVerticalBox();
				int sign0=(int)Math.random()*10;
				que=new JLabel(RoW[sign0].q);
				b.add(que);
				b.add(Box.createVerticalStrut(5));
				b.add(new  JLabel("����Ϊ1���ж��⣬����20�����������\n"));
				b.add(Box.createVerticalStrut(5));
				panel.setBackground(Color.LIGHT_GRAY);
				Box b0=Box.createHorizontalBox();
				T=new JRadioButton("T");
				F=new JRadioButton("F");
				
				group.add(T);
				group.add(F);

				T.addActionListener(al);
				F.addActionListener(al);
				
				b0.add(T);
				b0.add(F);
				b0.setName(RoW[sign0].ans);
				b.add(b0);
				panel.add(b);
				
			}
			add(panel,BorderLayout.CENTER);
			
			try {
				giveQuestion.wait();
			} catch (InterruptedException e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
			validate();
			
		}
	}*/
 