import java.net.*;
import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
public class HW12_2 extends JFrame implements Runnable, ActionListener
{
    JTextField outMessage = new JTextField(12);
    JTextArea inMessage = new JTextArea(12,20); 
    JButton b = new JButton("��������");
    HW12_2()
    {
       super("�ͻ���2");    
       b.addActionListener(this);
    
       setBounds(350,100,320,200); setVisible(true);
    
       JPanel p = new JPanel();    
       p.add(outMessage);
       p.add(b);
    
       Container con=getContentPane();
       con.add(new JScrollPane(inMessage),BorderLayout.CENTER);
       con.add(p,BorderLayout.NORTH);
    
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       validate();
    
       Thread thread = new Thread(this);
       thread.start(); // �̸߳����������
    }
    public void actionPerformed(ActionEvent event)
    {
       // ������ť��������
       byte b[]=outMessage.getText().trim().getBytes();
       try
       {
          InetAddress address = InetAddress.getByName("127.0.0.1");
          DatagramPacket data = new DatagramPacket(b,b.length,address,1235);
          DatagramSocket mail = new DatagramSocket();
          mail.send(data);
       }
       catch(Exception e){}     
    }
    public void run()
    {
       // ��������
       DatagramPacket pack = null;
       DatagramSocket mail = null;
       byte b[]=new byte[8192];
       try
       {
          pack = new DatagramPacket(b,b.length);    
          mail = new DatagramSocket(5679);
       }    
       catch(Exception e){} 

       while(true)
       {
           try
           {
              mail.receive(pack);           
              String message=new String(pack.getData(),0,pack.getLength());
              inMessage.append("�յ��������ԣ�"+pack.getAddress());
              inMessage.append("\n�յ������ǣ�"+message+"\n");
              inMessage.setCaretPosition(inMessage.getText().length());
           }
           catch(Exception e){}
       }
    }
    public static void main(String args[])
    {
       new HW12_2();
    }    
}

