import java.net.*;
import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
public class HW12_3 extends JFrame implements Runnable
{
    JTextField outMessage = new JTextField(12);
    JTextArea inMessage = new JTextArea(12,20); 
    HW12_3()
    {
       super("��������");    
    
       setBounds(350,100,320,200); setVisible(true);
    
       JPanel p = new JPanel();    
    
       Container con=getContentPane();
       con.add(new JScrollPane(inMessage),BorderLayout.CENTER);
       con.add(p,BorderLayout.NORTH);
    
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       validate();
    
       Thread thread = new Thread(this);
       thread.start(); // �̸߳����������
    }
    public void run()
    {
       // ��������
       DatagramPacket pack = null;
       DatagramSocket mail = null;
       byte b[]=new byte[8192];
       try
       {
    	   pack = new DatagramPacket(b,b.length);  
          mail = new DatagramSocket(1234);
       }    
       catch(Exception e){} 
       
       DatagramPacket pack0 = null;
       DatagramSocket mail0 = null;
       byte b0[]=new byte[8192];
       try
       {
    	   pack0 = new DatagramPacket(b0,b0.length);  
          mail0 = new DatagramSocket(1235);
       }    
       catch(Exception e){} 
       
       while(true)
       {
           try
           {
              mail.receive(pack); 
              String message=new String(pack.getData(),0,pack.getLength());   
              b=pack.getData();
            	  InetAddress address = InetAddress.getByName("127.0.0.1");
                  DatagramPacket data = new DatagramPacket(b,b.length,address,5679);
                  mail.send(data);
              
             
              inMessage.append("�յ��������ԣ�"+pack.getAddress());
              inMessage.append("\n�յ������ǣ�"+message+"\n");
              inMessage.setCaretPosition(inMessage.getText().length());
           }
           catch(Exception e){}
           try
           {
              mail0.receive(pack0); 
              String message=new String(pack0.getData(),0,pack0.getLength());   
              b0=pack0.getData();
            	  InetAddress address = InetAddress.getByName("127.0.0.1");
                  DatagramPacket data = new DatagramPacket(b0,b0.length,address,5678);
                  mail0.send(data);
              
             
              inMessage.append("�յ��������ԣ�"+pack0.getAddress());
              inMessage.append("\n�յ������ǣ�"+message+"\n");
              inMessage.setCaretPosition(inMessage.getText().length());
           }
           catch(Exception e){}
       }
    }
    public static void main(String args[])
    {
       new HW12_3();
    }    
}

