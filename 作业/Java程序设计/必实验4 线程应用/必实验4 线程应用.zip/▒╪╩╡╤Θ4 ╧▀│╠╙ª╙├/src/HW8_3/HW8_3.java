package HW8_3;
class Bank implements Runnable
{
	int balance;
	Bank(int b)
	{
		balance=b;
	}
	public void run()
	{
		withdraw(100);
	}
	public synchronized void withdraw(int n)
	{
		balance-=n;
		System.out.println("Remaining balance : "+balance);
	}
}
public class HW8_3 {
	static public void main(String[]s)
	{
		Runnable account=new Bank(10000);
		Thread a=new Thread(account);
		Thread b=new Thread(account);
		Thread c=new Thread(account);
		
		a.start();
		b.start();
		c.start();
	}
}
