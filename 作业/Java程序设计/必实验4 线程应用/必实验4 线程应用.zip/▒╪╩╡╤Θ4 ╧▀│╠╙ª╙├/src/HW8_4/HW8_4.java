package HW8_4;
class Bridge implements Runnable
{
	public void run()
	{
		Cross();	
	}
	public synchronized void Cross()
	{
		System.out.println(Thread.currentThread().getName()+" is crossing the bridge. ");
	}
}
public class HW8_4 {
	public static void main(String[]s)
	{
		Bridge B=new Bridge();
		Thread[]a=new Thread[20];
		Thread[]b=new Thread[20];
		for(int n0=0;n0<20;n0++)
		{
			a[n0]=new Thread(B);
			a[n0].setName("E"+(n0+1));
			b[n0]=new Thread(B);
			b[n0].setName("W"+(n0+1));
		}
		for(int n0=0;n0<20;n0++)
		{
			a[n0].start();
			b[n0].start();
		}
	}
}
