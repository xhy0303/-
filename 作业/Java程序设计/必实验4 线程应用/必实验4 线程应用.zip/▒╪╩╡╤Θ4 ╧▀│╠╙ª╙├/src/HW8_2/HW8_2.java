package HW8_2;
class PrintMonth implements Runnable
{
	String[]month= {"OneJanuary","TwoFebruary","ThreeMarch","FourApril","FiveMay","SixJune","SevenJuly","EightAugust","NineSeptember","TenOctober","ElevenNovember","TwelveDecember"};
	public void run()
	{
		for(int n0=0;n0<12;n0++)
		{
			show(n0);
		}
	}
	public synchronized void show(int n0)
	{
		if(Thread.currentThread().getName().equals("N"))
		{
			System.out.print(n0+1);
			notifyAll();
			try
			{
				wait();
			}
			catch(InterruptedException e) {
			}
		}
		else
		{
			System.out.println(month[n0]);
			notifyAll();
			try
			{
				wait();
			}
			catch(InterruptedException e) {
			}
		}
		
	}
}
public class HW8_2 {
	public static void main(String[]s)
	{
		PrintMonth ptr=new PrintMonth();
		
		Thread a=new Thread(ptr);
		Thread b=new Thread(ptr);
		
		a.setName("N");
		b.setName("S");
		a.start();
		b.start();
	}
}
