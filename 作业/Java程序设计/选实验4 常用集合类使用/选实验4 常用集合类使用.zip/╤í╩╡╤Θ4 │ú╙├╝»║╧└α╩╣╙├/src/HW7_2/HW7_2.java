package HW7_2;
import java.util.Scanner;
class Matrix
{
	int r_num,c_num;
	int[][] elements;
	Matrix(int r,int c)
	{
		
		r_num=r;
		c_num=c;
		elements=new int[r_num][c_num];
		
			
	}
	void Creat()
	{
		Scanner reader=new Scanner(System.in);
		for(int r0=0;r0<r_num;r0++)
		{
			for(int c0=0;c0<c_num;c0++)
			{
				elements[r0][c0]=reader.nextInt();
			}
		}
	}
	Matrix add(Matrix a)
	{
		Matrix result=new Matrix(this.r_num,this.c_num);
		for(int r0=0;r0<this.r_num;r0++)
		{
			for(int c0=0;c0<this.c_num;c0++)
			{
				result.elements[r0][c0]=this.elements[r0][c0]+a.elements[r0][c0];
			}
		}
		
		return result;
	}
	Matrix mutply(Matrix a)
	{
		Matrix result=new Matrix(this.r_num,a.c_num);
		for(int r0=0;r0<this.r_num;r0++)
		{
			for(int c0=0;c0<a.c_num;c0++)
			{
				int num=0,c1=0,r1=0;
				for(;c1<this.c_num;c1++,r1++)
				{
					num+=(this.elements[r0][c1]*a.elements[r1][c0]);
				}
				result.elements[r0][c0]=num;
			}
		}
		return result;
	}
	void show()
	{
		for(int r0=0;r0<r_num;r0++)
		{
			for(int c0=0;c0<c_num;c0++)
			{
				if(c0==c_num-1)
					System.out.println(elements[r0][c0]);
				else
					System.out.printf("%d ", elements[r0][c0]);
			}
		}
	}
	
}
public class HW7_2 {
	public static void main(String[]s)
	{
		System.out.println("�������һ������Ĵ�С��");
		int r1,c1;
		Scanner reader=new Scanner(System.in);
		r1=reader.nextInt();
		c1=reader.nextInt();
		
		System.out.println("�������һ������");
		Matrix m1=new Matrix(r1,c1);
		m1.Creat();
		System.out.println("������ڶ�������Ĵ�С��");
		int r2,c2;
		r2=reader.nextInt();
		c2=reader.nextInt();
		if(r1==r2&&c1==c2)
		{
			System.out.println("������ڶ�������");
			Matrix m2=new Matrix(r2,c2);
			m2.Creat();
			Matrix m3=m1.add(m2);
			Matrix m4=m1.mutply(m2);
			m3.show();
			System.out.println();
			m4.show();
		}
		else
		{
			System.out.println("�ڶ�����������ټ���");
			return;
		}
	}
}
