<?php
	
	$bid=$_POST['id'];
	
	$link=mysqli_connect('localhost','root','','exp4');
	$res=mysqli_query($link,"select rental_id, customer_id from rentals
								where bag_id = '$bid' 
								order by rental_id desc");
	
	echo json_encode($res->fetch_all(MYSQLI_ASSOC));

?>