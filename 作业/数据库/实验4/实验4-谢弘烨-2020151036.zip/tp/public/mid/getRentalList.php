<?php
	
	$id=$_POST['id'];
	
	$link=mysqli_connect('localhost','root','','exp4');
	
	$res=mysqli_query($link,"call report_customer_amount('$id')");
	echo json_encode($res->fetch_all(MYSQLI_ASSOC));


?>