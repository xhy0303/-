<?php
	
	$cid=$_POST['id'];
	
	$link=mysqli_connect('localhost','root','','exp4');

	$res=mysqli_query($link,"select * from customers where customer_id = '$cid'");
	echo json_encode($res->fetch_all(MYSQLI_ASSOC));
	

?>