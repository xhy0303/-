<?php
	
	$rid=$_POST['id'];
	
	$link=mysqli_connect('localhost','root','','exp4');
	$res=mysqli_query($link,"call return_bag('$rid')");
	
	echo json_encode($res->fetch_all(MYSQLI_ASSOC));

?>