<?php
	
	$bid=$_POST['bag_id'];
	$bname=$_POST['bname'];
	$color=$_POST['color'];
	$maker=$_POST['maker'];
	$price=$_POST['price'];
	
	$link=mysqli_connect('localhost','root','','exp4');
	$res=mysqli_query($link,"call add_bag('$bid','$bname','$color','$maker','$price')");
	
	if($res)
		echo 'true';
	else 
		echo 'false';

?>