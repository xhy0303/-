<?php
	
	$bid=$_POST['bag_id'];
	$cid=$_POST['customer_id'];
	$date=$_POST['date_return'];
	
	$link=mysqli_connect('localhost','root','','exp4');
	$res=mysqli_query($link,"call add_rental('$cid','$bid','$date')");
	
	if($res)
		echo 'true';
	else 
		echo 'false';

?>