<?php
	
	$bid=$_POST['bag_id'];
	
	$link=mysqli_connect('localhost','root','','exp4');
	$res=mysqli_query($link,"delete from bags where bag_id='$bid'");
	
	if($res)
		echo 'true';
	else 
		echo 'false';

?>