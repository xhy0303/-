<?php
	
	$cid=$_POST['customer_id'];
	
	$link=mysqli_connect('localhost','root','','exp4');
	$res=mysqli_query($link,"delete from customers where customer_id='$cid'");
	
	if($res)
		echo 'true';
	else 
		echo 'false';

?>