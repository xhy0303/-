<?php
	
	$word=$_POST['word'];
	
	$link=mysqli_connect('localhost','root','','exp4');
	if($word!="")
	{
		$res=mysqli_query($link,"select * from bags where bag_id like '%$word%'
														or bname like '%$word%' 
														or color like '%$word%'
														or maker like '%$word%'
														or price like '%$word%'");
		echo json_encode($res->fetch_all(MYSQLI_ASSOC));
	}
	else
	{
		$res=mysqli_query($link,"select * from bags");
		echo json_encode($res->fetch_all(MYSQLI_ASSOC));
	}	

?>