<?php
	
	$word=$_POST['word'];
	
	$link=mysqli_connect('localhost','root','','exp4');
	if($word!="")
	{
		$res=mysqli_query($link,"select * from customers where customer_id like '%$word%'
														or first_name like '%$word%' 
														or last_name like '%$word%'
														or addr like '%$word%'
														or telephone like '%$word%'
														or email like '%$word%'
														or cell like '%$word%'
														or credit_card like '%$word%'");
		echo json_encode($res->fetch_all(MYSQLI_ASSOC));
	}
	else
	{
		$res=mysqli_query($link,"select * from customers");
		echo json_encode($res->fetch_all(MYSQLI_ASSOC));
	}	

?>