<?php
	
	$bid=$_POST['id'];
	
	$link=mysqli_connect('localhost','root','','exp4');

	$res=mysqli_query($link,"select * from bags where bag_id = '$bid'");
	echo json_encode($res->fetch_all(MYSQLI_ASSOC));
	

?>