<?php
	
	$cid=$_POST['customer_id'];
	$last_name=$_POST['last_name'];
	$first_name=$_POST['first_name'];
	$addr=$_POST['addr'];
	$telephone=$_POST['telephone'];
	$cell=$_POST['cell'];
	$email=$_POST['email'];
	$credit_card=$_POST['credit_card'];
	
	$link=mysqli_connect('localhost','root','','exp4');
	$res=mysqli_query($link,"insert into customers (`customer_id`, `last_name`, `first_name`, `addr`, `telephone`, `cell`, `email`, `credit_card`)
								values('$cid','$last_name','$first_name','$addr','$telephone','$cell','$email','$credit_card')");
	
	if($res)
		echo 'true';
	else 
		echo 'false';

?>